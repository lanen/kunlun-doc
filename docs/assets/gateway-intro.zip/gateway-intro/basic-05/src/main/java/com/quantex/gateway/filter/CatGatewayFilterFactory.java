package com.quantex.gateway.filter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractNameValueGatewayFilterFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * Create date 2020-02-11.
 *
 * @author evan
 */
public class CatGatewayFilterFactory extends AbstractNameValueGatewayFilterFactory {

  private static final Log log = LogFactory.getLog(CatGatewayFilterFactory.class);

  private static final String REQUEST_TIME_BEGIN = "requestTimeBegin";

  @Override
  public GatewayFilter apply(NameValueConfig config) {
    return new GatewayFilter() {
      @Override
      public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        exchange.getAttributes().put(REQUEST_TIME_BEGIN, System.currentTimeMillis());

        ServerHttpRequest request = exchange.getRequest().mutate()
            .header(config.getName(), config.getValue()).build();

        return chain.filter(exchange.mutate().request(request).build()).then(
            Mono.fromRunnable(() -> {
              Long startTime = exchange.getAttribute(REQUEST_TIME_BEGIN);
              if (startTime != null) {

                StringBuilder sb = new StringBuilder(exchange.getRequest().getURI().getRawPath())
                    .append(": ")
                    .append(System.currentTimeMillis() - startTime)
                    .append("ms")
                    .append(" params:").append(exchange.getRequest().getQueryParams());
                log.info(sb.toString());
              }
            }));
      }
    };
  }

}
